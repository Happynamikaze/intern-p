How to set up project?

Open index.html file with go live server.

click on add to cart button to open product detail page

live hosted website link : https://happynamikaze.github.io/intern-p/ 